#!/usr/bin/env python 
# -*- coding: utf-8 -*-
# @Time    : 2024/10/27 17:16
# @Author  : 兵
# @email    : 1747193328@qq.com
import numpy as np
from ase.io import read as ase_read
from calorine.nep import get_descriptors
from matplotlib import pyplot as plt
from sklearn.decomposition import PCA
config=[
    #(文件名,图例,图例颜色)
    # ("./dpdata.xyz","dpdata","red"),
    ("./train.xyz", "train", "#1F78B4"),
    ("./test.xyz", "test", "#FF983E"),
    ("./test-H2.xyz", "test-H2", "#33A02C"),
    ("./test-Mg and OH-ion.xyz", "test-Mg and OH-ion", "#FFDF33"),
    ("./test-MgO.xyz", "test-MgO", "#6A3D9A"),
    ("./test-Mg(O-H doped).xyz", "test-Mg(O-H doped)", "#FF0000"),
]

fit_data=[]

for info in config:

    atoms_list = ase_read(info[0],":", format="extxyz", do_not_split_by_at_sign=True)



    atoms_list_des = np.vstack([ get_descriptors(i, "nep.txt")   for i in atoms_list])

    fit_data.append(atoms_list_des)


reducer = PCA(n_components=2)
reducer.fit(np.vstack(fit_data))
fig = plt.figure()
ax = fig.add_subplot(111)  # 创建坐标轴对象
for index,array in enumerate(fit_data):
    proj = reducer.transform(array)
    plt.scatter(proj[:, 0], proj[:, 1], label=config[index][1], c=config[index][2])



ax.set_xlabel('PC-1')  # 设置X轴标签
ax.set_ylabel('PC-2')  # 设置Y轴标签
ax.set_title('PCA Projection of Data')  # 设置标题
ax.legend()  # 显示图例
#plt.legend()
#plt.axis('off')

plt.savefig("./distribution.png", dpi=600)
